<?php

/*

type: layout
content_type: static
name: Clean
position: 2
is_default: true
description: Clean layout

*/


?>
<?php include template_dir() . "header.php"; ?>

<div class="edit" rel="content" field="snow_content">
    <module type="layouts" template="skin-12"/>
</div>

<?php include template_dir() . "footer.php"; ?>

