# Snow

Inspired by the snow covering Vitosha Mounting, Snow Templates comes with minimal components design and natural colors.

Snow template allows you to create any kind of web templates like complete websites, landing pages, coming soon, blog, eCommerce .. etc. 

It comes with a wide range of pre-built page templates to make the mission of starting your online presence easier than it has been before.

## Features:

* +10 Page Templates (Home, Services, Portfolio, Blog ... others)
* eCommerce Support  (Shop Page, Products Feed, Shopping Cart and Checkout Page)
* Pixel Perfect Design
* Fully Responsive Layout
* User-Friendly Code
* Clean Markup
* Creative Design
* Multiple Skins Sliders
* Cross Browser Support
* Easy to Customize
* Well Documented
* Free Lifetime Updates
* Community Support
