<?php

/*

type: layout
content_type: dynamic
name: Portfolio
position: 3
description: Portfolio

*/


?>
<?php include template_dir() . "header.php"; ?>


<div class="edit" rel="content" field="snow_content">
    <module type="layouts" template="skin-10"/>
</div>

<?php include template_dir() . "footer.php"; ?>






