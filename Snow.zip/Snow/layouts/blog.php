<?php

/*

type: layout
content_type: dynamic
name: Blog
position: 3
description: Blog

*/


?>
<?php include template_dir() . "header.php"; ?>


<div class="edit" rel="content" field="snow_content">
    <module type="layouts" template="skin-9"/>
</div>

<?php include template_dir() . "footer.php"; ?>






