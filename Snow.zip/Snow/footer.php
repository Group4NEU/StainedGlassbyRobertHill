            <footer class="nk-footer">
                <div class="nk-footer-cont">
                    <div class="container" field="template-footer" rel="global">
                        <div class="container text-xs-center">
                            <div class="nk-footer-social">
                                <module type="social_links" id="social-icons-footer" template="default" />
                            </div>

                            <div class="nk-footer-text">
                                <p><?php print powered_by_link(); ?> | Design by: <a href="http://unvab.com" rel="nofollow" target="_blank">Unvab Design</a> | <a href="<?php print admin_url() ?>">Admin</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- END: Footer -->
        </div>

        <script type="text/javascript" src="{TEMPLATE_URL}assets/js/TweenMax.js"></script>
    </body>
</html>