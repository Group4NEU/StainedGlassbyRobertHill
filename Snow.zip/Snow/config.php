<?php

$config = array();
$config['name'] = "Snow";
$config['author'] = "Microweber";
$config['version'] = 1.5;
$config['url'] = "http://microweber.com";
$config['standalone_module_skins'] = true;
