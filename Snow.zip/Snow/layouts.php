<?php

/*

  type: layout
  content_type: static
  name: Layouts
  position: 11
  description: Home layout

*/

?>
<?php include template_dir() . "header.php"; ?>

<div class="edit" rel="content" field="snow_content">
    <module type="layouts" template="skin-1"/>
    <module type="layouts" template="skin-2"/>
    <module type="layouts" template="skin-3"/>
    <module type="layouts" template="skin-4"/>
    <module type="layouts" template="skin-5"/>
    <module type="layouts" template="skin-6"/>
    <module type="layouts" template="skin-7"/>
    <module type="layouts" template="skin-8"/>
    <module type="layouts" template="skin-9"/>
    <module type="layouts" template="skin-10"/>
    <module type="layouts" template="skin-11"/>
    <module type="layouts" template="skin-12"/>
    <module type="layouts" template="skin-13"/>
</div>

<?php include template_dir() . "footer.php"; ?>
