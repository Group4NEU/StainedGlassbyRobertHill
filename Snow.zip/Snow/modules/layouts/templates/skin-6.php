<?php

/*

type: layout

name: Testimonials

position: 6

*/

?>

<div class="nodrop edit safe-mode" field="layout-skin-6-<?php print $params['id'] ?>" rel="module">
    <module type="testimonials"/>
</div>