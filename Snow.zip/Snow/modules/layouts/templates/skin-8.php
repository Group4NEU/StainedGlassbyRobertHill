<?php

/*

type: layout

name: Google Maps Fulwidth

position: 8

*/

?>

<div class="nodrop edit safe-mode" field="layout-skin-8-<?php print $params['id'] ?>" rel="module">
    <div class="google-maps-wrapper">
        <module type="google_maps"/>
    </div>
</div>