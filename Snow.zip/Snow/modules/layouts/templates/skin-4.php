<?php

/*

type: layout

name: Contacts

position: 4

*/

?>

<div class="container nodrop edit safe-mode" field="layout-skin-4-<?php print $params['id'] ?>" rel="module" id="contact">
    <div class="nk-gap-5"></div>
    <div class="row vertical-gap">
        <div class="col-lg-5 allow-drop">
            <!-- START: Info -->
            <h2 class="display-4">Contact Info:</h2>
            <div class="nk-gap mnt-3"></div>

            <p>Praesent interdum congue mauris, et fringilla lacus pel vitae. Quisque nisl mauris, aliquam eu ultrices vel, conse vitae sapien at imperdiet risus. Quisque cursus risus id.
                fermentum, in auctor quam consectetur.</p>

            <ul class="nk-contact-info">
                <li>
                    <strong>Address:</strong> 10111 Santa Monica Boulevard, LA
                </li>
                <li>
                    <strong>Phone:</strong> +44 987 065 908
                </li>
                <li>
                    <strong>Email:</strong> info@Example.com
                </li>
                <li>
                    <strong>Fax:</strong> +44 987 065 909
                </li>
            </ul>
            <!-- END: Info -->
        </div>
        <div class="col-lg-7">
            <module type="contact_form" template="email"/>
        </div>
    </div>
    <div class="nk-gap-5"></div>
</div>