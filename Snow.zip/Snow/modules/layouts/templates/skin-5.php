<?php

/*

type: layout

name: Pictures slider

position: 5

*/

?>

<div class="nodrop edit safe-mode" field="layout-skin-5-<?php print $params['id'] ?>" rel="module">
    <module type="pictures"/>
</div>