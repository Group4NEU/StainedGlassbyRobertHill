<?php

/*

type: layout

name: Parallax with Icons

position: 7

*/

?>

<div class="nodrop edit safe-mode" field="layout-skin-7-<?php print $params['id'] ?>" rel="module">
    <module type="parallax" class="nk-box bg-dark-1 text-white"/>
</div>