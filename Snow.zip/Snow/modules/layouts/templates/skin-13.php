<?php

/*

type: layout

name: Clean Container

position: 0

*/

?>

<div class="nk-box bg-white nodrop edit safe-mode" field="layout-skin-13-<?php print $params['id'] ?>" rel="module">
    <div class="nk-gap-4 mt-5"></div>

    <div class="container">
        <div class="row">
            <div class="col-xs-12 allow-drop">
                <div class="mw-row">
                    <div class="mw-col" style="width:100%">
                        <div class="mw-col-container">
                            <div class="mw-empty"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-gap-2 mt-12"></div>
</div>