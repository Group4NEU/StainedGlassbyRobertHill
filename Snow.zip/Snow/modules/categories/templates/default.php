<?php

/*

type: layout

name: Default

description: List Navigation

*/

?>

<?php
$params['ul_class'] = 'nk-isotope-filter';
?>

<?php category_tree($params); ?>
